<?php
require_once("Operations.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MyGuests Management</title>
</head>
<body>
  <h1>MyGuests Management</h1>
  <?php
  try{
    $oper = new Operations();
    $resultado = $oper->getMyGuest(1);
    echo $resultado;
  }
  catch (PDOException $e) {
    echo "<br><p style='color:red;'>DB Error: " . $e->getMessage() . "</p><br>";
  } catch (Exception $e) {
    echo "<br><p style='color:red;'>Error: " . $e->getMessage() . "</p><br>";
  } finally {
    //Close connection
    $oper->closeConnection();
  }
  ?>
</body>
</html>